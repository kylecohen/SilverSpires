// Unity adapter placeholder.
